# Line Break

Use the `<br>` tag to force a line break in text.

**Example:**

```
Add line breaks wherever you want

Add line breaks <br>wherever <br>you <br>want
```

![](images/TMP_RichTextLineBreak.png)<br/>
_Adding line breaks_
