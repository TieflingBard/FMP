# Sprite Shader



## Properties

|Property:||Function:|
|--|--|--|
|**Sprite Texture**   |   |   |
|**Tiling X/Y**   |   |   |
|**Offset X/Y**  |   |   |
|**Tint**   |   |   |
|**Stencil Comparison**   |   |   |
|**Stencil ID**   |   |   |
|**Stencil Operation**   |   |   |
|**Stencil Write Mask**   |   |   |
|**Stencil Read Mask**   |   |   |
|**Color Mask**   |   |   |
|**Clip Rect**   |   |   |
|**Use Alpha Clip**   |   |   |
|**Render Queue**   |   |   |
|   |From Shader   |   |
|   |Geometry   |   |
|   |Alpha Test   |   |
|   |Transparent   |   |
|Double Sided Global Illumination   |   |   |
